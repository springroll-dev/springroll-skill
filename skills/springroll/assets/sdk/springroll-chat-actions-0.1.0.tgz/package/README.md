# @springroll/chat-actions

Install this package from a built SpringRoll checkout or its packed `.tgz`. It is not automatically published to npm.

```sh
# In the SpringRoll repository, using Node 24:
npx tsx scripts/build-chat-actions-sdk.mts
npm pack ./packages/chat-actions --pack-destination ./packages/chat-actions

# In the application:
npm install /absolute/path/to/springroll/packages/chat-actions
```

The package supports Next.js route handlers/serverless functions, plain Node and Docker servers, and native Cloudflare Workers. It verifies opaque SpringRoll delegations using the app's server-side `sba_` identity and calls a mandatory application authorization callback for every exposed record. A manifest declaration requests capabilities; an owner must approve the exact release/collection before ChatGPT can use it.

```ts
import { createChatActionHandler } from '@springroll/chat-actions';
import { createD1ActionStore } from '@springroll/chat-actions/d1';
import { authorizeOwnTask, exampleTaskManifest } from '@springroll/chat-actions/example';

const handler = createChatActionHandler({
  controlPlaneUrl: new URL(env.SPRINGROLL_DATA_URL).origin,
  applicationToken: env.SPRINGROLL_DATA_TOKEN,
  manifest: exampleTaskManifest,
  store: createD1ActionStore(env.DB),
  authorize: authorizeOwnTask,
  createRecord: ({ principal, data }) => ({
    ...data,
    owner_membership_id: principal.membershipId,
  }),
});
```

Mount the handler only at `/.well-known/springroll/actions`. For Next.js App Router, export it as `POST` from `app/.well-known/springroll/actions/route.ts`. For Workers, call it from the matching route in `fetch(request, env)`. Plain Node servers use `nodeChatActionListener(handler)` from `@springroll/chat-actions/node`; the same server runs in a Docker image.

Postgres and D1 adapters require the exported `POSTGRES_ACTION_SCHEMA` or `D1_ACTION_SCHEMA` installed through app migrations. Postgres callers supply a SQL query adapter and a transaction callback that uses the same connection for all statements. Redis callers use `createRedisActionStore(createUpstashActionClient(url, token))`; keep these keys persistent and non-evicting, with no TTL on records, receipts or audit. The SDK never accepts SQL text or Redis commands from the chat input.

Mutations conditionally write the record, immutable receipt and audit together. An update requires the current record version. A duplicate operation returns its first result. Reconcile lost responses with the original envelope and `mode: 'receipt'`; never treat a timeout as proof that no write happened. Record authorization remains the app's responsibility: replace the example owner rule with the application's real policy.

The repository's `scripts/e2e-mcp/chat-app-fixtures.mts` produces portable, bundled examples for Next.js/Postgres, Node/Postgres, Node/Redis, Worker/D1, and Docker/Postgres without requiring a registry publication. The fixtures use the actual SDK code, not a parallel mock implementation.
